package FlightSearch.com.capgemini.flightSearch;

public class FlightSearch {

}
