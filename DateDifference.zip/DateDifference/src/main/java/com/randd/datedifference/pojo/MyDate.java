package com.randd.datedifference.pojo;

public class MyDate {
	
	int dd, mm, yyyy;

	public MyDate(int day, int month, int year) {
		
		if(day<1 || day>31 || month<1 || month>12 || year<=0 ||( month==2 && checkDay(day, month,year)==0) )
		{
			throw new RuntimeException("Invalid date");
		}
		this.dd = day;
		this.mm = month;
		this.yyyy = year;
	}
	
	//Day validation with respect to month
	private int checkDay(int day, int month, int year) {
		
		if( (year%4==0 && year%100!=0 || year%400==0) && day>29 )
			return 0;
		else if(day>28)
			return 0;
		return 1;
	}

	public int getDd() {
		return dd;
	}

	public int getMm() {
		return mm;
	}

	public int getYyyy() {
		return yyyy;
	}
		
}
