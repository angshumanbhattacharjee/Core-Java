package com.randd.datedifference.service;

import javax.management.RuntimeErrorException;

import com.randd.datedifference.pojo.MyDate;

public class DateDifferenceService {
	
	public static int JAN_DAYS = 31;
	public static int FEB_DAYS = 28;
	public static int MAR_DAYS = 31;
	public static int APR_DAYS = 30;
	public static int MAY_DAYS = 31;
	public static int JUN_DAYS = 30;
	public static int JUL_DAYS = 31;
	public static int AUG_DAYS = 31;
	public static int SEP_DAYS = 30;
	public static int OCT_DAYS = 31;
	public static int NOV_DAYS = 30;
	public static int DEC_DAYS = 31;
	
	static int[] monthDays = new int[]{0, JAN_DAYS, FEB_DAYS, MAR_DAYS, APR_DAYS, MAY_DAYS, JUN_DAYS, JUL_DAYS, AUG_DAYS, SEP_DAYS, OCT_DAYS, NOV_DAYS, DEC_DAYS}; //days in months
	
	public static int getDateDifference( MyDate startDate, MyDate endDate) {
		
		if( (startDate.getYyyy()>endDate.getYyyy()) || (equalYear(startDate, endDate) && startDate.getMm()>endDate.getMm() ) ||  (equalYear(startDate, endDate) && equalMonth(startDate, endDate) && startDate.getDd()>endDate.getDd()) )
		{
			throw new RuntimeException("Start date should not be greater than end date");
		}
		
		else if( equalDay(startDate, endDate) && equalMonth(startDate, endDate) && equalYear(startDate, endDate) ) {
			return 0;
		}
		else if(equalYear(startDate, endDate) && equalMonth(startDate, endDate))
		{
			return endDate.getDd() - startDate.getDd();
		}
		else if(equalYear(startDate, endDate) && !equalMonth(startDate, endDate)){
			return remainigDaysInMonth(startDate)+daysInIntervingMonth(startDate,endDate)+daysInLeadingMonth(endDate);
		}
		return remianingDaysInYear(startDate)+daysInInterviningYear(startDate,endDate)+daysInLeadingYear(endDate);
	}
	
	private static int daysInLeadingYear(MyDate endDate) {
		
		MyDate startDate = new MyDate(1, 1, endDate.getYyyy());
		return remainigDaysInMonth(startDate)+daysInIntervingMonth(startDate,endDate)+daysInLeadingMonth(endDate)+1;
	}

	private static int daysInInterviningYear(MyDate startDate, MyDate endDate) {
		int year = endDate.getYyyy()-1, noOfLeapYearsLeft=0;
		while(year!=startDate.getYyyy())
			noOfLeapYearsLeft+=callLeapYear(year--);
		return noOfLeapYearsLeft+ 365*(endDate.getYyyy()-startDate.getYyyy()-1);
	}

	private static int remianingDaysInYear(MyDate startDate) {
		MyDate endDate = new MyDate(31, 12, startDate.getYyyy());
		if(equalYear(startDate, endDate) && equalMonth(startDate, endDate))
		{
			return endDate.getDd() - startDate.getDd();
		}
		else
			return remainigDaysInMonth(startDate)+daysInIntervingMonth(startDate,endDate)+daysInLeadingMonth(endDate);
}

	//Sets date for FEB and returns 1 if leap year - acts as both SetDateForFeb and isLeapYear
	static int callLeapYear( int year)
	{
		if(year%4==0 && year%100!=0 || year%400==0)
		{
			monthDays[2]=29;
			return 1;
		}
		else
		{
			monthDays[2]=28;
			return 0;
		}
	}
	
	
	public static int daysInLeadingMonth(MyDate endDate) {
		return endDate.getDd();
	}
	
	public static int daysInIntervingMonth(MyDate startDate, MyDate endDate) {
		int month=endDate.getMm()-1, days=0;
		callLeapYear(startDate.getYyyy());
		while(month!=startDate.getMm())
			days+= monthDays[month--];
		return days;
	}
	
	public static  int remainigDaysInMonth(MyDate startDate) {
		return monthDays[startDate.getMm()]-startDate.getDd();
	}
	
	private static boolean equalYear(MyDate startDate, MyDate endDate) {
		return startDate.getYyyy()==endDate.getYyyy();
	}

	private static boolean equalMonth(MyDate startDate, MyDate endDate) {
		return startDate.getMm()==endDate.getMm();
	}

	private static boolean equalDay(MyDate startDate, MyDate endDate) {
		return startDate.getDd()==endDate.getDd();
	}
	
}
